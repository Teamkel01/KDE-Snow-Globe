#!/bin/bash
set -e
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

echo ""
echo "Installing Apps"
echo ""

sudo pacman -S --needed --noconfirm plasma-pa qt5-tools qt6-tools kde-cli-tools

sleep 1

echo ""
echo "Installing Snow Globe themes..."

mkdir -p ~/.local/share/plasma/desktoptheme/
mkdir -p ~/.local/share/aurorae/themes/
cp -r "$SCRIPT_DIR/Snow-Globe-Style" ~/.local/share/plasma/desktoptheme/
cp -r "$SCRIPT_DIR/Snow-Globe-Window" ~/.local/share/aurorae/themes/

sleep 1
echo ""
echo "Applying Settings.."

kwriteconfig6 --file plasmarc --group Theme --key name "Snow-Globe-Style"
kwriteconfig6 --file kwinrc --group org.kde.kdecoration2 --key library "org.kde.kwin.aurorae"
kwriteconfig6 --file kwinrc --group org.kde.kdecoration2 --key theme "__aurorae__svg__Snow-Globe-Window"
kwriteconfig6 --file kwinrc --group Plugins --key shakecursorEnabled false
kwriteconfig6 --file ksplashrc --group KSplash --key Theme None
kwriteconfig6 --file kdeglobals --group General --key AccentColor "#FFFFFF"
qdbus org.kde.KWin /KWin reconfigure || true

if [ -f "$SCRIPT_DIR/Backgrounds/ArchAlyaBackground.png" ]; then
    plasma-apply-wallpaperimage "$SCRIPT_DIR/Backgrounds/ArchAlyaBackground.png"
fi

sleep 1
sync

echo ""
echo "Logging Out In.."

sleep 1
echo ""
echo "3"
sleep 1
echo "2"
sleep 1
echo "1"
sleep 1

qdbus org.kde.Shutdown /Shutdown logout || loginctl terminate-user $USER
